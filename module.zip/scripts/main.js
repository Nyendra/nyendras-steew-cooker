/**
 * Nyendra's Steew Cooker
 * Main entry point
 */

// Log module initialization
Hooks.once("ready", () => {
  console.log("Nyendra's Steew Cooker | Module initialized");
});
